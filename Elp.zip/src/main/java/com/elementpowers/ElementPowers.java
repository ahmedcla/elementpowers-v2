package com.elementpowers;

import com.mojang.brigadier.CommandDispatcher;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;

public class ElementPowers implements ModInitializer {
	public static final String MOD_ID = "elementpowers";

	private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();

	@Override
	public void onInitialize() {
		PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
			ServerPlayer p = context.player();
			if (payload.action() == 0) use(p);
			else if (payload.action() == 1) cycle(p);
		});

		ServerLifecycleEvents.SERVER_STARTED.register(PowerData::load);
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			PowerData.save();
			Scheduler.clear();
		});

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			Scheduler.tick();
			for (ServerPlayer p : server.getPlayerList().getPlayers()) {
				PowerData.Entry en = PowerData.get(p.getUUID());
				if (en != null && en.element == 10) Abilities.record(p);
			}
		});

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> register(dispatcher));
	}

	// ---------- gameplay ----------

	private static void bar(ServerPlayer p, String s) {
		p.displayClientMessage(Component.literal(s), true);
	}

	private static void use(ServerPlayer p) {
		PowerData.Entry en = PowerData.get(p.getUUID());
		if (en == null) {
			bar(p, "No element yet. An admin must run /powers roll");
			return;
		}
		int idx = PowerData.selected(p.getUUID(), en.level);
		Abilities.Ability ab = Abilities.ALL[en.element][idx];
		ServerLevel lv = (ServerLevel) p.level();
		long now = lv.getGameTime();
		long[] cd = COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new long[4]);
		if (now < cd[idx]) {
			bar(p, ab.name() + " cooldown: " + ((cd[idx] - now + 19) / 20) + "s");
			return;
		}
		cd[idx] = now + ab.cooldown();
		ab.use().run(p, lv);
		bar(p, Abilities.NAMES[en.element] + " | " + ab.name());
	}

	private static void cycle(ServerPlayer p) {
		PowerData.Entry en = PowerData.get(p.getUUID());
		if (en == null) return;
		int cur = PowerData.selected(p.getUUID(), en.level);
		int next = (cur + 1) % (en.level + 1);
		PowerData.select(p.getUUID(), next);
		Abilities.Ability ab = Abilities.ALL[en.element][next];
		bar(p, "Selected: L" + (next + 1) + " " + ab.name());
	}

	// ---------- commands ----------

	private static void register(CommandDispatcher<CommandSourceStack> d) {
		d.register(Commands.literal("powers")
				.then(Commands.literal("info").executes(ctx -> {
					ServerPlayer p = ctx.getSource().getPlayerOrException();
					PowerData.Entry en = PowerData.get(p.getUUID());
					String t = en == null
							? "No element yet."
							: Abilities.NAMES[en.element] + " - level " + (en.level + 1) + " (" + Abilities.LEVEL_NAMES[en.level] + ")";
					ctx.getSource().sendSuccess(() -> Component.literal(t), false);
					return 1;
				}))
				.then(Commands.literal("roll")
						.requires(src -> src.permissions().hasPermission(Permissions.COMMANDS_MODERATOR))
						.executes(ctx -> roll(ctx.getSource().getServer(), ctx.getSource())))
				.then(Commands.literal("reset")
						.requires(src -> src.permissions().hasPermission(Permissions.COMMANDS_MODERATOR))
						.executes(ctx -> {
							PowerData.resetAll();
							COOLDOWNS.clear();
							ctx.getSource().sendSuccess(() -> Component.literal("All powers wiped. Run /powers roll again."), true);
							return 1;
						}))
				.then(Commands.literal("levelup")
						.requires(src -> src.permissions().hasPermission(Permissions.COMMANDS_MODERATOR))
						.then(Commands.argument("player", EntityArgument.player())
								.executes(ctx -> level(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"), 1))))
				.then(Commands.literal("leveldown")
						.requires(src -> src.permissions().hasPermission(Permissions.COMMANDS_MODERATOR))
						.then(Commands.argument("player", EntityArgument.player())
								.executes(ctx -> level(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"), -1)))));
	}

	/** Gives an unused random element to every online player that has none. Existing elements never change. */
	private static int roll(MinecraftServer server, CommandSourceStack src) {
		List<Integer> free = new ArrayList<>();
		for (int i = 0; i < Abilities.COUNT; i++) if (!PowerData.elementTaken(i)) free.add(i);
		Collections.shuffle(free);

		int given = 0;
		for (ServerPlayer p : server.getPlayerList().getPlayers()) {
			if (PowerData.get(p.getUUID()) != null) continue;
			if (free.isEmpty()) {
				p.displayClientMessage(Component.literal("No free elements left!"), false);
				continue;
			}
			int el = free.remove(0);
			PowerData.create(p.getUUID(), el);
			COOLDOWNS.remove(p.getUUID());
			p.displayClientMessage(Component.literal("Your element: " + Abilities.NAMES[el]
					+ " | Level 1: " + Abilities.ALL[el][0].name()
					+ " | R = use, G = switch ability"), false);
			given++;
		}
		final int n = given;
		src.sendSuccess(() -> Component.literal("Rolled elements for " + n + " player(s)."), true);
		return given;
	}

	private static int level(CommandSourceStack src, ServerPlayer target, int delta) {
		PowerData.Entry en = PowerData.get(target.getUUID());
		if (en == null) {
			src.sendFailure(Component.literal(target.getName().getString() + " has no element yet."));
			return 0;
		}
		en.level = Math.max(0, Math.min(3, en.level + delta));
		PowerData.select(target.getUUID(), en.level);
		PowerData.save();
		Abilities.Ability ab = Abilities.ALL[en.element][en.level];
		target.displayClientMessage(Component.literal("Level " + (en.level + 1) + " ("
				+ Abilities.LEVEL_NAMES[en.level] + "): " + ab.name()), false);
		src.sendSuccess(() -> Component.literal(target.getName().getString() + " is now level " + (en.level + 1)), true);
		return 1;
	}
}
