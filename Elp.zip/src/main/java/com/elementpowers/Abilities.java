package com.elementpowers;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 12 elements x 4 levels. Index order must match NAMES.
 * Level 1 = index 0 ... Level 4 = index 3.
 */
public final class Abilities {
	public interface Use {
		void run(ServerPlayer p, ServerLevel lv);
	}

	public record Ability(String name, int cooldown, Use use) {}

	public static final String[] NAMES = {
		"Earth", "Wind", "Lightning", "Fire", "Ice", "Water",
		"Darkness", "Light", "Nature", "Magnetism", "Time", "Mind"
	};
	public static final String[] LEVEL_NAMES = {"Novice", "Adept", "Expert", "Legendary"};
	public static final int COUNT = NAMES.length;

	public static final Ability[][] ALL = new Ability[COUNT][];

	// ---------- helpers ----------

	static List<LivingEntity> near(ServerPlayer p, ServerLevel lv, double r) {
		return lv.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
				e -> e != p && e.isAlive() && e.distanceToSqr(p) <= r * r);
	}

	static void fx(LivingEntity e, String id, int ticks, int amp) {
		BuiltInRegistries.MOB_EFFECT.get(Identifier.withDefaultNamespace(id))
				.ifPresent(h -> e.addEffect(new MobEffectInstance(h, ticks, amp)));
	}

	static void hurt(ServerPlayer p, ServerLevel lv, LivingEntity e, float dmg) {
		e.hurtServer(lv, lv.damageSources().playerAttack(p), dmg);
	}

	static void part(ServerLevel lv, ParticleOptions t, double x, double y, double z, int n, double spread, double speed) {
		lv.sendParticles(t, x, y, z, n, spread, spread, spread, speed);
	}

	static void burst(ServerLevel lv, ParticleOptions t, Entity e, int n) {
		part(lv, t, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), n, 0.5, 0.05);
	}

	static void push(Entity e, Vec3 v) {
		e.setDeltaMovement(v);
		e.hurtMarked = true;
	}

	static Vec3 dirTo(Vec3 from, Vec3 to) {
		Vec3 d = to.subtract(from);
		if (d.lengthSqr() < 1.0E-6) return new Vec3(0, 0, 0);
		return d.normalize();
	}

	static List<LivingEntity> cone(ServerPlayer p, ServerLevel lv, double range, double minDot) {
		Vec3 eye = p.getEyePosition();
		Vec3 look = p.getLookAngle();
		List<LivingEntity> out = new ArrayList<>();
		for (LivingEntity e : near(p, lv, range)) {
			Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
			double d = to.length();
			if (d < 0.1) continue;
			if (to.scale(1.0 / d).dot(look) >= minDot) out.add(e);
		}
		return out;
	}

	static LivingEntity target(ServerPlayer p, ServerLevel lv, double range, double minDot) {
		return cone(p, lv, range, minDot).stream()
				.min(Comparator.comparingDouble(e -> e.distanceToSqr(p))).orElse(null);
	}

	static void ray(ServerLevel lv, ServerPlayer p, ParticleOptions t, double len) {
		Vec3 s = p.getEyePosition().add(0, -0.2, 0);
		Vec3 l = p.getLookAngle();
		for (double d = 1; d < len; d += 0.7) {
			Vec3 q = s.add(l.scale(d));
			lv.sendParticles(t, q.x, q.y, q.z, 1, 0, 0, 0, 0);
		}
	}

	static void bolt(ServerLevel lv, double x, double y, double z) {
		LightningBolt b = EntityType.LIGHTNING_BOLT.create(lv, EntitySpawnReason.TRIGGERED);
		if (b != null) {
			b.setPos(x, y, z);
			lv.addFreshEntity(b);
		}
	}

	static void msg(ServerPlayer p, String s) {
		p.displayClientMessage(Component.literal(s), false);
	}

	static void fly(ServerPlayer p, int ticks, double speed) {
		fx(p, "slow_falling", ticks + 40, 0);
		Scheduler.repeat(ticks, i -> {
			if (!p.isAlive()) return;
			push(p, p.getLookAngle().scale(speed));
		});
	}

	static Ability a(String name, int cd, Use u) {
		return new Ability(name, cd, u);
	}

	// ---------- Time rewind history ----------
	private static final Map<UUID, Deque<double[]>> HISTORY = new HashMap<>();

	public static void record(ServerPlayer p) {
		Deque<double[]> q = HISTORY.computeIfAbsent(p.getUUID(), k -> new ArrayDeque<>());
		q.addLast(new double[] {p.getX(), p.getY(), p.getZ(), p.getHealth()});
		while (q.size() > 20) q.pollFirst();
	}

	// ---------- catalog ----------
	static {
		// 0 EARTH
		ALL[0] = new Ability[] {
			a("Tremor Sense", 400, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 20)) fx(e, "glowing", 100, 0);
			}),
			a("Stone Wall", 600, (p, lv) -> {
				Vec3 look = p.getLookAngle();
				Vec3 f = new Vec3(look.x, 0, look.z);
				f = f.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : f.normalize();
				Vec3 side = new Vec3(-f.z, 0, f.x);
				List<BlockPos> placed = new ArrayList<>();
				for (int w = -1; w <= 1; w++) {
					for (int h = 0; h <= 2; h++) {
						Vec3 v = p.position().add(f.scale(3)).add(side.scale(w));
						BlockPos bp = BlockPos.containing(v.x, p.getY() + h, v.z);
						if (lv.getBlockState(bp).isAir()) {
							lv.setBlockAndUpdate(bp, Blocks.STONE.defaultBlockState());
							placed.add(bp);
						}
					}
				}
				Scheduler.later(200, () -> {
					for (BlockPos bp : placed) {
						if (lv.getBlockState(bp).is(Blocks.STONE)) lv.removeBlock(bp, false);
					}
				});
			}),
			a("Earthquake", 800, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 8)) {
					hurt(p, lv, e, 6);
					fx(e, "slowness", 60, 2);
					push(e, new Vec3(0, 0.6, 0));
					burst(lv, ParticleTypes.EXPLOSION, e, 1);
				}
			}),
			a("Stone Giant", 2400, (p, lv) -> {
				fx(p, "resistance", 300, 3);
				fx(p, "strength", 300, 1);
				fx(p, "slowness", 300, 0);
				burst(lv, ParticleTypes.POOF, p, 30);
			})
		};

		// 1 WIND
		ALL[1] = new Ability[] {
			a("Gust", 200, (p, lv) -> {
				Vec3 look = p.getLookAngle();
				for (LivingEntity e : cone(p, lv, 8, 0.7)) push(e, look.scale(1.6).add(0, 0.3, 0));
				ray(lv, p, ParticleTypes.CLOUD, 8);
			}),
			a("Wind Leap", 200, (p, lv) -> {
				Vec3 look = p.getLookAngle();
				push(p, new Vec3(look.x * 0.9, 1.1, look.z * 0.9));
				fx(p, "slow_falling", 100, 0);
				burst(lv, ParticleTypes.CLOUD, p, 15);
			}),
			a("Flight", 600, (p, lv) -> fly(p, 80, 0.9)),
			a("Tornado", 1200, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 10)) {
					push(e, new Vec3((p.getRandom().nextDouble() - 0.5) * 0.6, 1.4, (p.getRandom().nextDouble() - 0.5) * 0.6));
					hurt(p, lv, e, 4);
				}
				Scheduler.repeat(30, i -> part(lv, ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 25, 3, 0.1));
			})
		};

		// 2 LIGHTNING
		ALL[2] = new Ability[] {
			a("Spark", 100, (p, lv) -> {
				LivingEntity t = target(p, lv, 12, 0.9);
				ray(lv, p, ParticleTypes.ELECTRIC_SPARK, 12);
				if (t != null) {
					hurt(p, lv, t, 3);
					fx(t, "slowness", 20, 4);
					burst(lv, ParticleTypes.ELECTRIC_SPARK, t, 20);
				}
			}),
			a("Lightning Dash", 600, (p, lv) -> {
				fx(p, "speed", 80, 4);
				fx(p, "haste", 80, 1);
				burst(lv, ParticleTypes.ELECTRIC_SPARK, p, 30);
			}),
			a("Chain Lightning", 1200, (p, lv) -> {
				List<LivingEntity> list = near(p, lv, 15);
				list.sort(Comparator.comparingDouble(e -> e.distanceToSqr(p)));
				for (int i = 0; i < Math.min(4, list.size()); i++) {
					LivingEntity e = list.get(i);
					bolt(lv, e.getX(), e.getY(), e.getZ());
				}
			}),
			a("Thunderstorm", 3600, (p, lv) -> Scheduler.repeat(60, i -> {
				if (i % 5 != 0) return;
				double ang = p.getRandom().nextDouble() * Math.PI * 2;
				double dist = 4 + p.getRandom().nextDouble() * 9;
				bolt(lv, p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
			}))
		};

		// 3 FIRE
		ALL[3] = new Ability[] {
			a("Warmth", 600, (p, lv) -> {
				fx(p, "fire_resistance", 1200, 0);
				p.setRemainingFireTicks(0);
				burst(lv, ParticleTypes.FLAME, p, 20);
			}),
			a("Fireball", 160, (p, lv) -> {
				ray(lv, p, ParticleTypes.FLAME, 15);
				for (LivingEntity e : cone(p, lv, 15, 0.93)) {
					hurt(p, lv, e, 6);
					e.setRemainingFireTicks(100);
					burst(lv, ParticleTypes.FLAME, e, 20);
				}
			}),
			a("Flame Aura", 1200, (p, lv) -> {
				fx(p, "fire_resistance", 140, 0);
				Scheduler.repeat(100, i -> {
					part(lv, ParticleTypes.FLAME, p.getX(), p.getY() + 1, p.getZ(), 6, 1.2, 0.02);
					if (i % 5 != 0) return;
					for (LivingEntity e : near(p, lv, 3)) {
						e.setRemainingFireTicks(80);
						hurt(p, lv, e, 2);
					}
				});
			}),
			a("Solar Blast", 3600, (p, lv) -> {
				fx(p, "resistance", 60, 4);
				fx(p, "fire_resistance", 200, 0);
				lv.explode(p, p.getX(), p.getY(), p.getZ(), 4.0f, Level.ExplosionInteraction.NONE);
				for (LivingEntity e : near(p, lv, 10)) {
					hurt(p, lv, e, 14);
					e.setRemainingFireTicks(160);
					push(e, dirTo(p.position(), e.position()).scale(1.5).add(0, 0.5, 0));
				}
				burst(lv, ParticleTypes.FLAME, p, 100);
			})
		};

		// 4 ICE
		ALL[4] = new Ability[] {
			a("Cold Touch", 100, (p, lv) -> {
				LivingEntity t = target(p, lv, 6, 0.8);
				if (t == null) return;
				t.setTicksFrozen(300);
				fx(t, "slowness", 60, 1);
				hurt(p, lv, t, 2);
				burst(lv, ParticleTypes.SNOWFLAKE, t, 25);
			}),
			a("Ice Shield", 600, (p, lv) -> {
				fx(p, "resistance", 200, 1);
				fx(p, "absorption", 200, 2);
				burst(lv, ParticleTypes.SNOWFLAKE, p, 40);
			}),
			a("Slippery Ground", 900, (p, lv) -> {
				fx(p, "speed", 160, 3);
				for (LivingEntity e : near(p, lv, 6)) fx(e, "slowness", 100, 2);
				part(lv, ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 0.2, p.getZ(), 60, 3, 0.02);
			}),
			a("Blizzard", 2400, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 12)) {
					e.setTicksFrozen(400);
					fx(e, "slowness", 200, 3);
					hurt(p, lv, e, 4);
				}
				Scheduler.repeat(40, i -> part(lv, ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 2, p.getZ(), 40, 6, 0.05));
			})
		};

		// 5 WATER
		ALL[5] = new Ability[] {
			a("Aqua Breath", 600, (p, lv) -> {
				fx(p, "water_breathing", 3600, 0);
				fx(p, "dolphins_grace", 600, 0);
			}),
			a("Water Whip", 160, (p, lv) -> {
				Vec3 look = p.getLookAngle();
				ray(lv, p, ParticleTypes.SPLASH, 10);
				for (LivingEntity e : cone(p, lv, 10, 0.8)) {
					hurt(p, lv, e, 5);
					push(e, look.scale(1.2).add(0, 0.2, 0));
				}
			}),
			a("Healing Waters", 1200, (p, lv) -> {
				p.heal(8);
				fx(p, "regeneration", 100, 2);
				for (LivingEntity e : near(p, lv, 8)) {
					if (e instanceof Player) {
						e.heal(6);
						fx(e, "regeneration", 100, 2);
					}
				}
				burst(lv, ParticleTypes.HAPPY_VILLAGER, p, 30);
			}),
			a("Tsunami", 3000, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 14)) {
					push(e, dirTo(p.position(), e.position()).scale(2.2).add(0, 0.4, 0));
					hurt(p, lv, e, 6);
					fx(e, "slowness", 40, 1);
				}
				Scheduler.repeat(30, i -> part(lv, ParticleTypes.SPLASH, p.getX(), p.getY() + 1, p.getZ(), 60, 6, 0.2));
			})
		};

		// 6 DARKNESS
		ALL[6] = new Ability[] {
			a("Cloak", 1200, (p, lv) -> fx(p, "invisibility", 600, 0)),
			a("Night Eye", 600, (p, lv) -> fx(p, "night_vision", 3600, 0)),
			a("Shadow Step", 300, (p, lv) -> {
				Vec3 from = p.getEyePosition();
				Vec3 look = p.getLookAngle();
				var hit = lv.clip(new ClipContext(from, from.add(look.scale(12)),
						ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
				Vec3 loc = hit.getLocation();
				if (hit.getType() != HitResult.Type.MISS) loc = loc.subtract(look.scale(0.8));
				burst(lv, ParticleTypes.PORTAL, p, 30);
				p.teleportTo(loc.x, loc.y - p.getEyeHeight(), loc.z);
				burst(lv, ParticleTypes.PORTAL, p, 30);
			}),
			a("Lord of Darkness", 3000, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 12)) {
					fx(e, "blindness", 200, 0);
					fx(e, "darkness", 200, 0);
					fx(e, "slowness", 100, 1);
				}
				fx(p, "speed", 200, 2);
				fx(p, "invisibility", 200, 0);
				fx(p, "strength", 200, 1);
			})
		};

		// 7 LIGHT
		ALL[7] = new Ability[] {
			a("Flash", 300, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 10)) {
					fx(e, "blindness", 60, 0);
					fx(e, "glowing", 100, 0);
				}
				burst(lv, ParticleTypes.END_ROD, p, 40);
			}),
			a("Reveal", 600, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 25)) fx(e, "glowing", 200, 0);
			}),
			a("Laser Beam", 200, (p, lv) -> {
				ray(lv, p, ParticleTypes.END_ROD, 25);
				LivingEntity t = target(p, lv, 25, 0.985);
				if (t != null) {
					hurt(p, lv, t, 8);
					t.setRemainingFireTicks(60);
				}
			}),
			a("Sunrise", 3600, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 12)) {
					if (e instanceof Player) {
						fx(e, "regeneration", 100, 1);
						fx(e, "resistance", 100, 1);
					} else {
						hurt(p, lv, e, 10);
						fx(e, "blindness", 100, 0);
					}
				}
				burst(lv, ParticleTypes.END_ROD, p, 120);
			})
		};

		// 8 NATURE
		ALL[8] = new Ability[] {
			a("Green Thumb", 400, (p, lv) -> {
				int ok = 0;
				for (int dx = -4; dx <= 4 && ok < 12; dx++) {
					for (int dz = -4; dz <= 4 && ok < 12; dz++) {
						for (int dy = -1; dy <= 1; dy++) {
							BlockPos bp = p.blockPosition().offset(dx, dy, dz);
							if (BoneMealItem.applyBonemeal(new ItemStack(Items.BONE_MEAL), lv, bp, p)) {
								ok++;
								break;
							}
						}
					}
				}
			}),
			a("Beast Tongue", 400, (p, lv) -> {
				int n = 0;
				for (LivingEntity e : near(p, lv, 20)) {
					if (e instanceof Animal) {
						fx(e, "glowing", 200, 0);
						fx(e, "regeneration", 100, 0);
						n++;
					}
				}
				msg(p, "Animals nearby: " + n);
			}),
			a("Binding Vines", 900, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 10)) {
					fx(e, "slowness", 100, 6);
					fx(e, "poison", 100, 0);
					hurt(p, lv, e, 3);
					burst(lv, ParticleTypes.HAPPY_VILLAGER, e, 10);
				}
			}),
			a("Living Forest", 3000, (p, lv) -> {
				fx(p, "regeneration", 200, 1);
				fx(p, "absorption", 400, 1);
				for (LivingEntity e : near(p, lv, 12)) {
					if (e instanceof Player) {
						fx(e, "regeneration", 200, 1);
					} else {
						fx(e, "poison", 200, 1);
						fx(e, "slowness", 200, 2);
						hurt(p, lv, e, 8);
					}
				}
				Scheduler.repeat(40, i -> part(lv, ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1, p.getZ(), 20, 5, 0.1));
			})
		};

		// 9 MAGNETISM
		ALL[9] = new Ability[] {
			a("Metal Sense", 400, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 25)) {
					if (e.getArmorValue() > 0) fx(e, "glowing", 200, 0);
				}
			}),
			a("Pull", 120, (p, lv) -> {
				Vec3 look = p.getLookAngle();
				Vec3 eye = p.getEyePosition();
				List<Entity> list = lv.getEntitiesOfClass(Entity.class, p.getBoundingBox().inflate(12),
						e -> e != p && !e.isSpectator());
				for (Entity e : list) {
					Vec3 to = e.position().subtract(eye);
					double d = to.length();
					if (d < 0.5 || to.scale(1.0 / d).dot(look) < 0.7) continue;
					push(e, dirTo(e.position(), p.position()).scale(1.1));
				}
				ray(lv, p, ParticleTypes.ELECTRIC_SPARK, 12);
			}),
			a("Magnetic Shield", 1200, (p, lv) -> {
				fx(p, "resistance", 200, 2);
				Scheduler.repeat(200, i -> {
					if (i % 2 != 0) return;
					for (Projectile pr : lv.getEntitiesOfClass(Projectile.class, p.getBoundingBox().inflate(6))) {
						if (pr.getOwner() == p) continue;
						double speed = Math.max(0.8, pr.getDeltaMovement().length());
						push(pr, dirTo(p.position(), pr.position()).scale(speed));
					}
				});
			}),
			a("Magnetic Flight", 1800, (p, lv) -> fly(p, 120, 1.0))
		};

		// 10 TIME
		ALL[10] = new Ability[] {
			a("Time Sense", 400, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 15)) fx(e, "glowing", 100, 0);
				fx(p, "speed", 200, 0);
			}),
			a("Rewind", 200, (p, lv) -> {
				Deque<double[]> q = HISTORY.get(p.getUUID());
				if (q == null || q.isEmpty()) return;
				double[] s = q.peekFirst();
				burst(lv, ParticleTypes.PORTAL, p, 30);
				p.teleportTo(s[0], s[1], s[2]);
				p.setHealth((float) Math.min(p.getMaxHealth(), Math.max(p.getHealth(), s[3])));
				p.setDeltaMovement(Vec3.ZERO);
				p.hurtMarked = true;
			}),
			a("Slow Time", 1200, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 12)) {
					fx(e, "slowness", 100, 3);
					fx(e, "weakness", 100, 1);
				}
				fx(p, "speed", 100, 2);
				fx(p, "haste", 100, 2);
			}),
			a("Time Stop", 6000, (p, lv) -> {
				List<Mob> frozen = new ArrayList<>();
				for (LivingEntity e : near(p, lv, 16)) {
					fx(e, "slowness", 80, 10);
					fx(e, "mining_fatigue", 80, 10);
					fx(e, "weakness", 80, 10);
					if (e instanceof Mob m && !m.isNoAi()) {
						m.setNoAi(true);
						frozen.add(m);
					}
				}
				Scheduler.later(80, () -> {
					for (Mob m : frozen) m.setNoAi(false);
				});
			})
		};

		// 11 MIND
		ALL[11] = new Ability[] {
			a("Empathy", 400, (p, lv) -> {
				for (LivingEntity e : near(p, lv, 30)) fx(e, "glowing", 200, 0);
			}),
			a("Mind Read", 100, (p, lv) -> {
				LivingEntity t = target(p, lv, 25, 0.93);
				if (t == null) {
					msg(p, "No one in sight.");
					return;
				}
				String info = t.getName().getString() + " | HP " + Math.round(t.getHealth());
				if (t instanceof Player pl) info += " | holding: " + pl.getMainHandItem().getHoverName().getString();
				msg(p, info);
			}),
			a("Telekinesis", 160, (p, lv) -> {
				LivingEntity t = target(p, lv, 18, 0.95);
				if (t == null) return;
				Scheduler.repeat(50, i -> {
					if (!t.isAlive() || !p.isAlive()) return;
					if (i == 49) {
						push(t, p.getLookAngle().scale(2.0));
						hurt(p, lv, t, 4);
						return;
					}
					Vec3 goal = p.getEyePosition().add(p.getLookAngle().scale(4));
					Vec3 d = goal.subtract(t.position().add(0, t.getBbHeight() / 2, 0));
					push(t, d.scale(0.35));
				});
			}),
			a("Domination", 1800, (p, lv) -> {
				LivingEntity t = target(p, lv, 25, 0.93);
				if (t == null) {
					msg(p, "No one in sight.");
					return;
				}
				if (t instanceof Mob m) {
					List<LivingEntity> others = lv.getEntitiesOfClass(LivingEntity.class, t.getBoundingBox().inflate(12),
							e -> e != t && e != p && e.isAlive() && !(e instanceof Player));
					others.sort(Comparator.comparingDouble(e -> e.distanceToSqr(t)));
					if (!others.isEmpty()) m.setTarget(others.get(0));
					fx(t, "glowing", 200, 0);
				} else {
					fx(t, "nausea", 200, 0);
					fx(t, "slowness", 100, 2);
				}
				burst(lv, ParticleTypes.ENCHANT, t, 40);
			})
		};
	}

	private Abilities() {}
}
