package com.elementpowers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

/** Saved to <world>/elementpowers.json */
public class PowerData {
	public static class Entry {
		public int element = -1;
		public int level = 0; // 0..3
	}

	public Map<String, Entry> players = new LinkedHashMap<>();

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static PowerData instance = new PowerData();
	private static Path file;
	private static final Map<UUID, Integer> selected = new HashMap<>();

	public static void load(MinecraftServer server) {
		file = server.getWorldPath(LevelResource.ROOT).resolve("elementpowers.json");
		instance = new PowerData();
		selected.clear();
		if (Files.exists(file)) {
			try (BufferedReader r = Files.newBufferedReader(file)) {
				PowerData d = GSON.fromJson(r, PowerData.class);
				if (d != null && d.players != null) instance = d;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public static void save() {
		if (file == null) return;
		try (BufferedWriter w = Files.newBufferedWriter(file)) {
			GSON.toJson(instance, w);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Entry get(UUID id) {
		return instance.players.get(id.toString());
	}

	public static Entry create(UUID id, int element) {
		Entry e = new Entry();
		e.element = element;
		instance.players.put(id.toString(), e);
		selected.remove(id);
		save();
		return e;
	}

	public static boolean elementTaken(int element) {
		for (Entry e : instance.players.values()) if (e.element == element) return true;
		return false;
	}

	public static void resetAll() {
		instance.players.clear();
		selected.clear();
		save();
	}

	public static int selected(UUID id, int level) {
		int s = selected.getOrDefault(id, level);
		return Math.max(0, Math.min(level, s));
	}

	public static void select(UUID id, int idx) {
		selected.put(id, idx);
	}
}
